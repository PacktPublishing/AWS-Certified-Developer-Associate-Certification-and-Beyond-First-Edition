import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { TodoService } from './todo.service';
import { CreateTodoDto } from './dto/create-todo.dto';
import { UpdateTodoDto } from './dto/update-todo.dto';
import { ApiTags } from '@nestjs/swagger';

@Controller('todo')
@ApiTags('Todos')
export class TodoController {
  constructor(private readonly todoService: TodoService) {}

  @Post()
  create(@Body() createTodoDto: CreateTodoDto) {
    return this.todoService.create({
      ...createTodoDto,
      startDate: new Date(createTodoDto.startDate).toISOString(),
      endDate: new Date(createTodoDto.endDate).toISOString(),
    });
  }

  @Get()
  findAll() {
    return this.todoService.todos({});
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.todoService.todo({ id: +id });
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateTodoDto: UpdateTodoDto) {
    return this.todoService.updateTodo({
      where: { id: +id },
      data: updateTodoDto,
    });
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.todoService.deleteTodo({ id: +id });
  }
}
