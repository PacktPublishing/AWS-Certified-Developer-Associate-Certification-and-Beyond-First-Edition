// export const BASE_URL = "http://localhost";
export const BASE_URL = window.BASE_URL ?? "/production";
// export const BASE_URL =
//   "https://54ezuklam2.execute-api.us-east-1.amazonaws.com/production";
